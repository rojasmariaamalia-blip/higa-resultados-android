# HIGA Resultados Android

App Android con WebView para abrir la consulta de laboratorio del HIGA.

Objetivo de esta primera versión:
- abrir HIGA dentro de la app;
- permitir que la app ejecute JavaScript sobre la página cargada;
- preparar la selección de D.N.I.;
- preparar el campo DNI;
- dejar preparada la base para completar fechas y automatizar la búsqueda.

Importante: la aplicación necesita que el usuario tenga autorización para acceder al sistema HIGA. No contiene usuarios ni contraseñas.
